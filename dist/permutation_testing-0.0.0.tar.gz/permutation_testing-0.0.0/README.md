# permutation_test
Permutation test for MATLAB and Python. 
